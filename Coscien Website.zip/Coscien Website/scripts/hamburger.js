$("#menu").click(function() {
    if ($("#avi").hasClass("hidden")) {
        $("#avi").removeClass("hidden");
    } else {
        $("#avi").addClass("hidden");
    }
});
