
$("#container1").hover(function() {
  // TODO: snippet(s) to respond to when the mouse enters the element.
  $("#cover-text1").removeClass("hidden");
}, function() {
  // TODO: snippet(s) to respond to when the mouse leaves the element.
  $("#cover-text1").addClass("hidden");
});

$("#container2").hover(function() {
  // TODO: snippet(s) to respond to when the mouse enters the element.
  $("#cover-text2").removeClass("hidden");
}, function() {
  // TODO: snippet(s) to respond to when the mouse leaves the element.
  $("#cover-text2").addClass("hidden");
});

$("#container3").hover(function() {
  // TODO: snippet(s) to respond to when the mouse enters the element.
  $("#cover-text3").removeClass("hidden");
}, function() {
  // TODO: snippet(s) to respond to when the mouse leaves the element.
  $("#cover-text3").addClass("hidden");
});

$("#container4").hover(function() {
  // TODO: snippet(s) to respond to when the mouse enters the element.
  $("#cover-text4").removeClass("hidden");
}, function() {
  // TODO: snippet(s) to respond to when the mouse leaves the element.
  $("#cover-text4").addClass("hidden");
});

$("#container5").hover(function() {
  // TODO: snippet(s) to respond to when the mouse enters the element.
  $("#cover-text5").removeClass("hidden");
}, function() {
  // TODO: snippet(s) to respond to when the mouse leaves the element.
  $("#cover-text5").addClass("hidden");
});
