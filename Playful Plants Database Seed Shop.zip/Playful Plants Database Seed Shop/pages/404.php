<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <title>Error Page</title>
  <link rel="stylesheet" type="text/css" href="public/styles/site.css"/>
</head>

<body>

<?php include('includes/header.php'); ?>
<div class= "content1">
<h1> Sorry, the page you have requested does not exist. </h1>
<h2> Please request a valid page </h2>
</div>
</body>

</html>
