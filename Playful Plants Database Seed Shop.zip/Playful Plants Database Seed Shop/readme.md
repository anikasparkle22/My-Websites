This is the completed database seed shop for the playful plants website. 
You can filter the database on the main page and sign in to  the administrative database with the username Admin and password monkey
On the administrative database you can add or delete a plant as well as filter
Read about the design process on the design-plan folder.
This website uses PHP, MySQL, HTML, CSS
