function hm() {
  var Navigation = document.getElementById("avi");
     if ("block"!= Navigation.style.display) {
       Navigation.style.display = "block";
    }
    else if ("block"== Navigation.style.display) {
      Navigation.style.display = "none";
    }
}
