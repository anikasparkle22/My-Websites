<footer>
    <p><?php echo $source;?><cite><a href="https://www.downtownithaca.com/apple-harvest-festival/">Downtown Ithaca </a></cite></p>

    <script type="text/javascript" src="public/scripts/jquery-3.6.0.js"></script>
    <script type="text/javascript" src="public/scripts/drop-down.js"></script>
  </footer>
