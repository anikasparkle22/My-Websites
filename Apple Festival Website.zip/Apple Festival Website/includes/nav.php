
 <header>
      <nav>
        <a href="#menu" class="active" onclick="hm()"> ☰ </a>
          <div id="avi" class="hidden">
          <a href="/">About</a>
            <a href="/festival-vendors">Market</a>
            <a href="/entertainment">Entertainment</a>
            <a href="/map-of-festival">Map</a>
            <a href="/join-us">Join Us</a>
        </div>
      </nav>
    </header>

    <img src="public/images/hp1.png" alt="apple harvest festival logo" class= "head1">
       <!-- Source: (original work) Anika Tasnim -->
